THEME CODING – HOW TO USE

1. Unzip this folder. Keep everything in it together.
2. Open index.html in Firefox or Chrome.
3. Click "Choose folder", pick this folder, then click Start.
   (Your browser may ask to confirm. Nothing is uploaded anywhere.)

CODING
1–8      tick a theme (IMM ISL CRI SOV ECON LAND CULT DEF)
0        no theme
'        write a note
Enter    save and go to the next post
Shift+Enter   skip
← →      move without saving
P        compare a possible duplicate
B M V Space   bold reading, sound, subtitles, pause
Double-click a picture or video to enlarge it.

SAVING
Your work is kept in the browser as you go, but only in that browser.
When you finish (or stop for the day), click "Save sheet".
A copy of coding_sheet.xlsx goes to your Downloads folder.
Send that file back.

To carry on later, put the downloaded sheet in this folder in place of the old one.
