'use strict';

var THEMES = [
  ['IMM', 'Immigration and asylum'], ['ISL', 'Islam and Islamism'],
  ['CRI', 'Crime, security and punishment'], ['SOV', 'Sovereignty, nation and identity'],
  ['ECON', 'Economy and public services'], ['LAND', 'Land, agriculture, energy and environment'],
  ['CULT', 'Gender, family and culture war'], ['DEF', 'Defence and foreign relations']
];
var NONE = 'no_theme';
var KEYS = { '1': 'IMM', '2': 'ISL', '3': 'CRI', '4': 'SOV', '5': 'ECON', '6': 'LAND', '7': 'CULT', '8': 'DEF', '0': NONE };
var NEED = ['i', 'account', 'pid'].concat(THEMES.map(function (t) { return t[0]; }),
  [NONE, 'notes', 'status', 'coded_at']);
var IMG = /^(jpe?g|png|webp|gif)$/i, VID = /^(mp4|webm|mov|m4v)$/i;

var S = {
  corpus: null, nFiles: 0, book: null, sheetFile: '', sheet: null, col: {}, rows: [], byI: {},
  copiesOf: {}, pos: 0, on: {}, last: null, unsaved: 0, store: null, pending: null,
  bionic: true, sound: false, subs: true, paused: false, urls: { main: [], cmp: [], big: [] }
};
var $ = function (id) { return document.getElementById(id); };

function pref(k, v) {
  try {
    if (v === undefined) return localStorage.getItem('ah.' + k);
    localStorage.setItem('ah.' + k, v);
  } catch (e) { }
  return null;
}

function say(msg, cls) {
  var el = $('status');
  el.textContent = msg || ''; el.className = cls || '';
  clearTimeout(say.t);
  if (msg) say.t = setTimeout(function () { if (el.textContent === msg) { el.textContent = ''; el.className = ''; } }, 3200);
}

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
  });
}

function stamp() {
  var d = new Date(), p = function (n) { return (n < 10 ? '0' : '') + n; };
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' +
    p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
}


function indexCorpus(files) {
  var idx = {}, n = 0;
  Array.prototype.forEach.call(files, function (f) {
    var parts = (f.webkitRelativePath || f.name).split('/');
    if (parts.length !== 4 || parts[1] !== 'corpus') return;
    var acc = parts[2], name = parts[3], m, post;
    var get = function (pid) {
      var a = idx[acc] = idx[acc] || {};
      return a[pid] = a[pid] || { media: [], ocr: {}, srt: {}, info: null };
    };
    if ((m = /^(.*)_info\.txt$/.exec(name))) { get(m[1]).info = f; n++; return; }
    if ((m = /^(.*)_(\d{2})\.(translated|transcribed)\.txt$/.exec(name))) {
      post = get(m[1]);
      if (!post.ocr[m[2]] || m[3] === 'translated') post.ocr[m[2]] = { file: f, kind: m[3] };
      n++; return;
    }
    if ((m = /^(.*)_(\d{2})\.srt$/.exec(name))) { get(m[1]).srt[m[2]] = f; n++; return; }
    if ((m = /^(.*)_(\d{2})\.([A-Za-z0-9]+)$/.exec(name)) && (IMG.test(m[3]) || VID.test(m[3]))) {
      get(m[1]).media.push({ n: m[2], file: f, video: VID.test(m[3]) }); n++;
    }
  });
  Object.keys(idx).forEach(function (a) {
    Object.keys(idx[a]).forEach(function (p) { idx[a][p].media.sort(function (x, y) { return x.n < y.n ? -1 : 1; }); });
  });
  return { idx: idx, n: n, accounts: Object.keys(idx).length };
}

function entry(row) {
  var a = S.corpus[row.account] || S.corpus[String(row.account).replace(/_+$/, '')] || {};
  return a[row.pid] || { media: [], ocr: {}, srt: {}, info: null };
}

function sections(text) {
  var out = [{ h: '', lines: [] }];
  text.replace(/^﻿/, '').split(/\r?\n/).forEach(function (ln) {
    var m = /^\s*(?:===|---)\s*(.+?)\s*(?:===|---)\s*$/.exec(ln);
    if (m) out.push({ h: m[1], lines: [] }); else out[out.length - 1].lines.push(ln);
  });
  return out.map(function (s) { return { h: s.h, body: s.lines.join('\n').trim() }; });
}

function pick(secs, re) {
  var hit = secs.filter(function (s) { return re.test(s.h) && s.body; });
  return hit.length ? hit[hit.length - 1] : null;
}

function captionText(raw) {
  var secs = sections(raw), en = pick(secs, /^English Translation$/i);
  return en ? en.body : secs[0].body;
}

function ocrText(raw, kind) {
  var secs = sections(raw), s;
  if ((s = pick(secs, /^English (Translation|Transcription) \(Manual/i))) return { text: s.body };
  if (kind === 'transcribed') return secs[0].body ? { text: secs[0].body } : null;
  s = pick(secs, /^TRANSLATED \(EN\)$/i);
  if (s && !/^TRANSLATION N\/A$/i.test(s.body)) return { text: s.body };
  s = pick(secs, /^ORIGINAL$/i);
  return s ? { text: s.body, note: 'no English translation, original text' } : null;
}

function srtText(raw) {
  var out = [];
  raw.replace(/^﻿/, '').split(/\r?\n/).forEach(function (ln) {
    var s = ln.trim();
    if (!s || /^\d+$/.test(s) || s.indexOf('-->') >= 0) return;
    if (out[out.length - 1] !== s) out.push(s);
  });
  return out.join('\n');
}

function toVtt(raw) {
  return 'WEBVTT\n\n' + raw.replace(/^﻿/, '').split(/\r?\n/).map(function (ln) {
    return ln.indexOf('-->') >= 0 ? ln.replace(/,/g, '.') : ln;
  }).join('\n') + '\n';
}

var textCache = {};
function texts(row) {
  var key = row.account + '/' + row.pid;
  if (textCache[key]) return Promise.resolve(textCache[key]);
  var e = entry(row), nn;
  var read = function (f) { return f ? f.text().catch(function () { return ''; }) : Promise.resolve(''); };
  var ocrN = Object.keys(e.ocr).sort(), srtN = Object.keys(e.srt).sort();
  return Promise.all([read(e.info)].concat(
    ocrN.map(function (n) { return read(e.ocr[n].file); }),
    srtN.map(function (n) { return read(e.srt[n]); })
  )).then(function (r) {
    var t = { caption: captionText(r[0]), ocr: [], srt: [], vtt: {} };
    ocrN.forEach(function (n, k) {
      var o = ocrText(r[1 + k], e.ocr[n].kind);
      if (o && o.text) t.ocr.push({ n: n, text: o.text, note: o.note });
    });
    srtN.forEach(function (n, k) {
      var raw = r[1 + ocrN.length + k], s = srtText(raw);
      if (s) t.srt.push({ n: n, text: s });
      t.vtt[n] = toVtt(raw);
    });
    return textCache[key] = t;
  });
}


var WORD = /[#@]?[0-9A-Za-zÀ-ÖØ-öø-ɏ][0-9A-Za-zÀ-ÖØ-öø-ɏ'’\-]*/g;

function bionic(word) {
  var frag = document.createDocumentFragment();
  var lead = word.replace(/^[#@]/, ''), pre = word.length - lead.length, L = lead.length;
  var n = L <= 3 ? 1 : L <= 6 ? 2 : L <= 9 ? 3 : Math.ceil(L * 0.4);
  if (pre) frag.appendChild(document.createTextNode(word.slice(0, pre)));
  var b = document.createElement('span');
  b.className = 'bf'; b.textContent = lead.slice(0, n);
  frag.appendChild(b);
  frag.appendChild(document.createTextNode(lead.slice(n)));
  return frag;
}

function textNode(text) {
  var d = document.createElement('div');
  d.className = 'body';
  if (!S.bionic) { d.textContent = text; return d; }
  var pos = 0, m;
  WORD.lastIndex = 0;
  while ((m = WORD.exec(text))) {
    if (m.index > pos) d.appendChild(document.createTextNode(text.slice(pos, m.index)));
    d.appendChild(bionic(m[0]));
    pos = m.index + m[0].length;
  }
  if (pos < text.length) d.appendChild(document.createTextNode(text.slice(pos)));
  return d;
}

function emptyNode() {
  var e = document.createElement('div');
  e.className = 'empty'; e.textContent = 'none';
  return e;
}

function fill(host, items) {
  host.textContent = '';
  if (!items.length) { host.appendChild(emptyNode()); return; }
  items.forEach(function (it) {
    if (items.length > 1) {
      var h = document.createElement('div'); h.className = 'subn'; h.textContent = '#' + it.n; host.appendChild(h);
    }
    if (it.note) {
      var w = document.createElement('div'); w.className = 'note'; w.textContent = it.note; host.appendChild(w);
    }
    host.appendChild(textNode(it.text));
  });
}

function fillCaption(host, t) {
  host.textContent = '';
  host.appendChild(t.caption ? textNode(t.caption) : emptyNode());
}


function url(bucket, blob) {
  var u = URL.createObjectURL(blob);
  S.urls[bucket].push(u);
  return u;
}
function release(bucket) {
  S.urls[bucket].forEach(function (u) { URL.revokeObjectURL(u); });
  S.urls[bucket] = [];
}

function mediaEl(bucket, m, vtt, opts) {
  var el;
  if (m.video) {
    el = document.createElement('video');
    el.src = url(bucket, m.file); el.loop = true; el.playsInline = true; el.preload = 'auto';
    el.muted = opts.muted; el.controls = !!opts.controls;
    if (vtt) {
      var tr = document.createElement('track');
      tr.kind = 'captions'; tr.srclang = 'en'; tr.label = 'English'; tr.default = true;
      tr.src = url(bucket, new Blob([vtt], { type: 'text/vtt' }));
      el.appendChild(tr);
      var mode = function () {
        for (var i = 0; i < el.textTracks.length; i++) el.textTracks[i].mode = S.subs ? 'showing' : 'hidden';
      };
      tr.addEventListener('load', mode); el.addEventListener('loadedmetadata', mode); setTimeout(mode, 300);
    }
    if (opts.play) el.play().catch(function () { });
  } else {
    el = document.createElement('img');
    el.src = url(bucket, m.file); el.alt = m.file.name; el.decoding = 'async';
  }
  return el;
}

function renderMedia(row, t) {
  release('main');
  var grid = $('grid'), media = entry(row).media, n = media.length;
  grid.textContent = '';
  grid.className = 'n' + (n <= 1 ? 1 : n === 2 ? 2 : n <= 6 ? 3 : 4);
  if (!n) {
    var e = document.createElement('div'); e.className = 'nomedia';
    e.textContent = 'no media found for ' + row.account + ' / ' + row.pid;
    grid.appendChild(e); return;
  }
  media.forEach(function (m, k) {
    var cell = document.createElement('div'); cell.className = 'cell';
    var el = mediaEl('main', m, t.vtt[m.n], { muted: !S.sound, controls: n === 1, play: !S.paused });
    el.addEventListener('dblclick', function () { enlarge(m, t.vtt[m.n]); });
    cell.appendChild(el);
    if (n > 1) { var g = document.createElement('span'); g.className = 'tag'; g.textContent = (k + 1) + '/' + n; cell.appendChild(g); }
    if (m.video) { var v = document.createElement('span'); v.className = 'tag vid'; v.textContent = 'video'; cell.appendChild(v); }
    grid.appendChild(cell);
  });
}

function videos(sel) { return Array.prototype.slice.call(document.querySelectorAll(sel || '#grid video')); }

function enlarge(m, vtt) {
  release('big');
  var box = $('big-in');
  box.textContent = '';
  box.appendChild(mediaEl('big', m, vtt, { muted: !S.sound, controls: true, play: true }));
  videos('#grid video').forEach(function (v) { v.pause(); });
  $('big').hidden = false;
}
function shrink() {
  $('big').hidden = true; $('big-in').textContent = ''; release('big');
  if (!S.paused) videos().forEach(function (v) { v.play().catch(function () { }); });
}


function cellTrue(v) {
  if (v === true) return true;
  if (typeof v === 'number') return v !== 0;
  return /^(x|1|true|yes|y)$/i.test(String(v == null ? '' : v).trim());
}

function loadSheet(book) {
  var sh = book.sheets.filter(function (s) { return /^coding$/i.test(s.name); })[0] || book.sheets[0];
  if (!sh || !sh.rows.length) throw new Error('the sheet is empty');
  var head = sh.rows[0].map(function (h) { return String(h == null ? '' : h).trim(); });
  var col = {};
  head.forEach(function (h, k) { if (h && !(h in col)) col[h] = k; });
  var miss = NEED.filter(function (n) { return !(n in col); });
  if (miss.length) throw new Error('the ' + sh.name + ' sheet is missing ' + miss.join(', '));
  var rows = [];
  for (var r = 1; r < sh.rows.length; r++) {
    var a = sh.rows[r], g = function (n) { return n in col ? a[col[n]] : null; };
    if (g('pid') == null || g('pid') === '') continue;
    var on = {};
    THEMES.forEach(function (t) { if (cellTrue(g(t[0]))) on[t[0]] = 1; });
    if (cellTrue(g(NONE))) on = { no_theme: 1 };
    var st = String(g('status') || '').trim().toLowerCase();
    rows.push({
      r: r, i: g('i'), account: String(g('account')), pid: String(g('pid')), date: g('date') == null ? '' : String(g('date')),
      dup: g('possible_dup_of') == null || g('possible_dup_of') === '' ? null : g('possible_dup_of'),
      on: st === 'coded' || st === 'resolved' ? on : {}, notes: g('notes') == null ? '' : String(g('notes')),
      status: st === 'coded' || st === 'resolved' ? 'coded' : st === 'skipped' ? 'skipped' : '',
      at: g('coded_at') == null ? '' : String(g('coded_at'))
    });
  }
  if (!rows.length) throw new Error('no posts in the ' + sh.name + ' sheet');
  S.sheet = sh; S.col = col; S.rows = rows; S.byI = {}; S.copiesOf = {};
  rows.forEach(function (x, k) { S.byI[String(x.i)] = k; });
  rows.forEach(function (x) {
    if (x.dup != null && String(x.dup) in S.byI) (S.copiesOf[String(x.dup)] = S.copiesOf[String(x.dup)] || []).push(x.i);
  });
}

function storeKey() { return 'ah.codes.' + S.sheetFile; }
function readStore() {
  try { return JSON.parse(localStorage.getItem(storeKey()) || '{}'); } catch (e) { return {}; }
}
function writeStore(obj) {
  try { localStorage.setItem(storeKey(), JSON.stringify(obj)); return true; } catch (e) { return false; }
}

function checkRestore() {
  var saved = readStore(), newer = {};
  Object.keys(saved).forEach(function (i) {
    var k = S.byI[i], rec = saved[i];
    if (k === undefined || !rec || !rec.at) return;
    if (!S.rows[k].at || rec.at > S.rows[k].at) newer[i] = rec;
  });
  var n = Object.keys(newer).length, box = $('restore');
  S.pending = n ? newer : null;
  if (!n) { box.hidden = true; return; }
  box.hidden = false;
  box.innerHTML = '<b>This browser holds ' + n + ' saved post' + (n === 1 ? '' : 's') +
    ' newer than the sheet.</b> Probably work from last time that was not saved to the sheet.' +
    '<div class="row"><button class="hbtn strong" id="b-keep">Restore them</button>' +
    '<button class="hbtn" id="b-drop">Ignore</button></div>';
  $('b-keep').onclick = function () { box.innerHTML = '<b>' + n + ' will be restored.</b>'; };
  $('b-drop').onclick = function () {
    S.pending = null;
    var s = readStore();
    Object.keys(newer).forEach(function (i) { delete s[i]; });
    writeStore(s);
    box.innerHTML = 'Ignored. The sheet is used as it is.';
  };
}

function applyRec(row, rec) {
  row.on = {};
  (rec.codes || []).forEach(function (c) { row.on[c] = 1; });
  row.notes = rec.notes || ''; row.status = rec.status; row.at = rec.at;
}

function exportSheet() {
  var sh = S.sheet, col = S.col;
  S.rows.forEach(function (x) {
    var a = sh.rows[x.r] = sh.rows[x.r] || [];
    var put = function (n, v) { a[col[n]] = v; };
    THEMES.forEach(function (t) { put(t[0], x.status === 'coded' ? (x.on[t[0]] ? 1 : 0) : null); });
    put(NONE, x.status === 'coded' ? (x.on[NONE] ? 1 : 0) : null);
    put('notes', x.notes || null);
    put('status', x.status || null);
    put('coded_at', x.at || null);
  });
  var blob = Xlsx.write(S.book);
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = S.sheetFile;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
  S.unsaved = 0; tally();
  say('sheet saved to your downloads', 'ok');
}


function tally() {
  var done = 0, sk = 0;
  S.rows.forEach(function (x) { if (x.status === 'coded') done++; else if (x.status === 'skipped') sk++; });
  $('progress').textContent = done + ' coded' + (sk ? ' · ' + sk + ' skipped' : '') + ' · ' +
    (S.rows.length - done - sk) + ' left' + (S.unsaved ? ' · ' + S.unsaved + ' not in the sheet yet' : '');
  $('b-export').classList.toggle('due', S.unsaved > 0);
}

function show(k) {
  closeCmp();
  S.pos = Math.max(0, Math.min(S.rows.length - 1, k));
  pref('pos.' + S.sheetFile, S.pos);
  var row = S.rows[S.pos];
  S.on = {}; Object.keys(row.on).forEach(function (c) { S.on[c] = 1; });
  S.last = null;
  $('notes').value = row.notes || '';
  $('pos').innerHTML = (S.pos + 1) + ' <small>/ ' + S.rows.length + '</small>';
  $('who').innerHTML = '<b>' + esc(row.account) + '</b> · ' + esc(row.pid) +
    (row.date ? ' · ' + esc(row.date) : '') + ' · post ' + esc(row.i) +
    (row.status === 'coded' ? '<span class="st">coded</span>' : row.status === 'skipped' ? '<span class="st skipped">skipped</span>' : '');
  paint();
  renderDup(row);
  var want = S.pos;
  return texts(row).then(function (t) {
    if (S.pos !== want) return;
    renderMedia(row, t);
    fillCaption($('cap'), t); fill($('ocr'), t.ocr); fill($('srt'), t.srt);
    $('text').scrollTop = 0;
  });
}

function rerenderText() {
  var row = S.rows[S.pos];
  texts(row).then(function (t) { fillCaption($('cap'), t); fill($('ocr'), t.ocr); fill($('srt'), t.srt); });
}

function renderDup(row) {
  var bar = $('dupbar'), key = String(row.i), copies = S.copiesOf[key] || [];
  bar.hidden = true; bar.classList.remove('first');
  if (row.dup != null) {
    var inSheet = String(row.dup) in S.byI;
    bar.hidden = false;
    bar.innerHTML = '<span class="tagd">POSSIBLE DUPLICATE</span> same media as post <b>' + esc(row.dup) + '</b>' +
      (inSheet ? '' : ' (not in this sheet)') + ', tool match, not checked' +
      (inSheet ? '<span class="hint2"><kbd>P</kbd> side by side</span>' : '');
  } else if (copies.length) {
    bar.hidden = false; bar.classList.add('first');
    bar.innerHTML = '<span class="tagd">POSSIBLE DUPLICATE</span> ' + copies.length + ' later post' +
      (copies.length === 1 ? '' : 's') + ' may repeat this one (' + copies.map(esc).join(', ') +
      '), tool match, not checked<span class="hint2"><kbd>P</kbd> side by side</span>';
  }
}

function buttons() {
  var host = $('codes');
  THEMES.concat([[NONE, 'nothing to tick']]).forEach(function (t) {
    var key = Object.keys(KEYS).filter(function (k) { return KEYS[k] === t[0]; })[0];
    var b = document.createElement('button');
    b.className = 'th' + (t[0] === NONE ? ' none' : ''); b.dataset.code = t[0];
    b.innerHTML = '<span class="k">' + key + '</span><span class="lab"><span class="cd">' +
      (t[0] === NONE ? 'No theme' : t[0]) + '</span><span class="nm">' + esc(t[1]) + '</span></span>';
    b.addEventListener('click', function () { toggle(t[0]); b.blur(); });
    host.appendChild(b);
  });
}

function paint() {
  var none = !!S.on[NONE];
  Array.prototype.forEach.call(document.querySelectorAll('.th'), function (b) {
    var c = b.dataset.code;
    b.classList.toggle('on', !!S.on[c]);
    b.classList.toggle('off', none && c !== NONE);
    b.classList.toggle('last', c === S.last);
  });
}

function toggle(code) {
  var now = !S.on[code];
  if (now && code === NONE) S.on = {};
  else if (now) delete S.on[NONE];
  if (now) S.on[code] = 1; else delete S.on[code];
  S.last = code;
  paint();
}

function save(status) {
  var row = S.rows[S.pos], codes = Object.keys(S.on);
  if (status === 'coded' && !codes.length) { say('tick a theme or No theme, or skip', 'warn'); return; }
  var rec = { codes: status === 'coded' ? codes : [], notes: $('notes').value.trim(), status: status, at: stamp() };
  applyRec(row, rec);
  var s = readStore(); s[String(row.i)] = rec;
  var ok = writeStore(s);
  S.unsaved++;
  tally();
  say(ok ? (status === 'coded' ? 'saved' : 'skipped') : 'saved here only, browser storage is off: save the sheet soon',
      ok ? 'ok' : 'warn');
  show(S.pos + 1);
}

function nextUncoded() {
  for (var k = 1; k <= S.rows.length; k++) {
    var j = (S.pos + k) % S.rows.length;
    if (S.rows[j].status !== 'coded') { show(j); return; }
  }
  say('everything is coded', 'ok');
}

function jump() {
  var q = $('jump').value.trim().toLowerCase();
  if (!q) return;
  var hit = -1;
  if (q in S.byI) hit = S.byI[q];
  else {
    for (var k = 1; k <= S.rows.length && hit < 0; k++) {
      var j = (S.pos + k) % S.rows.length, x = S.rows[j];
      if ((x.account + '/' + x.pid).toLowerCase().indexOf(q) >= 0) hit = j;
    }
  }
  if (hit < 0) { say('no post matches "' + q + '"', 'warn'); return; }
  $('jump').value = ''; $('jump').blur();
  show(hit);
}


function openCmp() {
  var row = S.rows[S.pos];
  var root = row.dup != null && String(row.dup) in S.byI ? String(row.dup) : String(row.i);
  var members = [root].concat((S.copiesOf[root] || []).map(String));
  if (members.length < 2) { say('no possible duplicate to compare', ''); return; }
  release('cmp');
  videos().forEach(function (v) { v.pause(); });
  var body = $('cmp-body');
  body.textContent = '';
  $('cmp').hidden = false;
  members.forEach(function (i) {
    var x = S.rows[S.byI[i]], me = x === row;
    var col = document.createElement('div'); col.className = 'col' + (me ? ' me' : '');
    col.innerHTML = '<h4><b>post ' + esc(x.i) + '</b> ' + esc(x.account) + ' <span class="dim">' + esc(x.pid) + '</span>' +
      (me ? ' <span class="me">this post</span>' : '') + '</h4>';
    body.appendChild(col);
    texts(x).then(function (t) {
      var med = document.createElement('div'), m = entry(x).media;
      med.className = 'cm';
      med.style.gridTemplateColumns = 'repeat(' + (m.length <= 1 ? 1 : m.length <= 4 ? 2 : 3) + ', 1fr)';
      m.forEach(function (mm) { med.appendChild(mediaEl('cmp', mm, t.vtt[mm.n], { muted: true, controls: true })); });
      col.appendChild(med);
      var tx = document.createElement('div'); tx.className = 'ct';
      var part = function (title, items) {
        var h = document.createElement('h5'); h.textContent = title; tx.appendChild(h);
        var d = document.createElement('div'); fill(d, items); tx.appendChild(d);
      };
      part('caption', t.caption ? [{ n: '', text: t.caption }] : []);
      if (t.ocr.length) part('text in the image', t.ocr);
      if (t.srt.length) part('subtitles', t.srt);
      col.appendChild(tx);
      var cc = document.createElement('div'); cc.className = 'cc';
      var on = me ? S.on : x.on, codes = Object.keys(on);
      cc.innerHTML = codes.length ? codes.map(function (c) {
        return '<span class="chip">' + (c === NONE ? 'no theme' : c) + '</span>';
      }).join('') : '<span class="empty">' + (me ? 'nothing ticked yet' : 'not coded yet') + '</span>';
      col.appendChild(cc);
    });
  });
}

function closeCmp() {
  if ($('cmp').hidden) return;
  $('cmp').hidden = true; $('cmp-body').textContent = ''; release('cmp');
  if (!S.paused) videos().forEach(function (v) { v.play().catch(function () { }); });
}


function flag(name, btn, on) {
  S[name] = on; pref(name, on ? '1' : '0');
  $(btn).classList.toggle('on', on);
}
function setBionic(on) { flag('bionic', 't-bionic', on); if (S.rows.length) rerenderText(); }
function setSound(on) { flag('sound', 't-sound', on); videos('video').forEach(function (v) { v.muted = !on; }); }
function setSubs(on) {
  flag('subs', 't-subs', on);
  videos('video').forEach(function (v) {
    for (var i = 0; i < v.textTracks.length; i++) v.textTracks[i].mode = on ? 'showing' : 'hidden';
  });
}
function setPause(on) {
  flag('paused', 't-pause', on);
  videos().forEach(function (v) { if (on) v.pause(); else v.play().catch(function () { }); });
}


function typing() {
  var a = document.activeElement;
  return a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA');
}

document.addEventListener('keydown', function (e) {
  if (document.body.classList.contains('setup')) return;
  if (e.key === 'Escape') {
    if (!$('cmp').hidden) closeCmp();
    else if (!$('big').hidden) shrink();
    else if (typing()) document.activeElement.blur();
    return;
  }
  if (typing()) {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (document.activeElement === $('jump')) jump(); else document.activeElement.blur();
    }
    return;
  }
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  if (!$('cmp').hidden || !$('big').hidden) {
    if (e.key.toUpperCase() === 'P' && !$('cmp').hidden) { e.preventDefault(); closeCmp(); }
    return;
  }
  var k = e.key.length === 1 ? e.key.toUpperCase() : e.key;
  if (k === 'Enter') { e.preventDefault(); save(e.shiftKey ? 'skipped' : 'coded'); }
  else if (k === 'ArrowRight') { e.preventDefault(); show(S.pos + 1); }
  else if (k === 'ArrowLeft' || k === 'Backspace') { e.preventDefault(); show(S.pos - 1); }
  else if (k === ' ') { e.preventDefault(); setPause(!S.paused); }
  else if (k === '/') { e.preventDefault(); $('jump').focus(); }
  else if (k === "'") { e.preventDefault(); $('notes').focus(); }
  else if (k === 'P') { e.preventDefault(); openCmp(); }
  else if (k === 'B') setBionic(!S.bionic);
  else if (k === 'M') setSound(!S.sound);
  else if (k === 'V') setSubs(!S.subs);
  else if (KEYS[k]) { e.preventDefault(); toggle(KEYS[k]); }
});


function ready() {
  $('b-start').disabled = !(S.corpus && S.book);
}

function openSheet(f) {
  var got = $('got-sheet');
  S.book = null; ready();
  $('restore').hidden = true;
  got.className = 'got'; got.textContent = 'reading ' + f.name + '…';
  Array.prototype.forEach.call(document.querySelectorAll('#sheets .hbtn'), function (b) {
    b.classList.toggle('strong', b.textContent === f.name);
  });
  f.arrayBuffer().then(Xlsx.read).then(function (book) {
    S.sheetFile = f.name;
    loadSheet(book);
    S.book = book;
    var done = S.rows.filter(function (x) { return x.status === 'coded'; }).length;
    got.textContent = 'sheet: ' + f.name + ', ' + S.rows.length + ' posts, ' + done + ' coded';
    checkRestore();
    ready();
  }).catch(function (err) {
    got.className = 'got bad'; got.textContent = f.name + ': ' + (err.message || 'could not read it');
  });
}

$('in-folder').addEventListener('change', function () {
  var files = this.files, r = indexCorpus(files), gc = $('got-corpus'), gs = $('got-sheet'), list = $('sheets');
  S.corpus = null; S.book = null; list.textContent = ''; list.hidden = true; $('restore').hidden = true;
  if (!r.accounts) {
    gc.className = 'got bad';
    gc.textContent = 'no corpus folder with account folders in it here';
  } else {
    S.corpus = r.idx; S.nFiles = r.n; gc.className = 'got';
    gc.textContent = 'corpus: ' + r.accounts + ' account folder' + (r.accounts === 1 ? '' : 's') + ', ' + r.n + ' files';
  }
  var sheets = Array.prototype.filter.call(files, function (f) {
    var parts = (f.webkitRelativePath || f.name).split('/');
    return parts.length === 2 && /\.xlsx$/i.test(f.name) && !/^(~\$|\.)/.test(f.name);
  });
  if (!sheets.length) {
    gs.className = 'got bad'; gs.textContent = 'no .xlsx next to the corpus folder';
  } else if (sheets.length === 1) {
    openSheet(sheets[0]);
  } else {
    gs.className = 'got'; gs.textContent = 'more than one spreadsheet here, pick one:';
    list.hidden = false;
    sheets.forEach(function (f) {
      var b = document.createElement('button');
      b.className = 'hbtn'; b.textContent = f.name;
      b.addEventListener('click', function () { openSheet(f); });
      list.appendChild(b);
    });
  }
  ready();
});

$('b-start').addEventListener('click', function () {
  var missing = S.rows.filter(function (x) { return !entry(x).media.length && !entry(x).info; }).length;
  if (S.pending) {
    Object.keys(S.pending).forEach(function (i) { applyRec(S.rows[S.byI[i]], S.pending[i]); });
    S.unsaved = Object.keys(S.pending).length;
  }
  document.body.classList.remove('setup');
  setBionic(pref('bionic') !== '0'); setSound(pref('sound') === '1');
  setSubs(pref('subs') !== '0'); setPause(false);
  tally();
  var p = parseInt(pref('pos.' + S.sheetFile), 10);
  show(isNaN(p) ? 0 : p).then(function () {
    if (missing) say(missing + ' post' + (missing === 1 ? '' : 's') + ' not found in the corpus folder', 'warn');
  });
});

buttons();
$('b-save').addEventListener('click', function () { save('coded'); });
$('b-skip').addEventListener('click', function () { save('skipped'); });
$('b-prev').addEventListener('click', function () { show(S.pos - 1); });
$('b-next').addEventListener('click', function () { show(S.pos + 1); });
$('b-uncoded').addEventListener('click', nextUncoded);
$('b-export').addEventListener('click', exportSheet);
$('t-bionic').addEventListener('click', function () { setBionic(!S.bionic); });
$('t-sound').addEventListener('click', function () { setSound(!S.sound); });
$('t-subs').addEventListener('click', function () { setSubs(!S.subs); });
$('t-pause').addEventListener('click', function () { setPause(!S.paused); });
$('cmp-close').addEventListener('click', closeCmp);
$('big').addEventListener('click', function (e) {
  if (e.target === $('big') || e.target.classList.contains('close') || e.target === $('big-in')) shrink();
});
Array.prototype.forEach.call(document.querySelectorAll('.act, .hbtn'), function (b) {
  b.addEventListener('mouseup', function () { b.blur(); });
});
window.addEventListener('beforeunload', function (e) {
  if (S.unsaved > 0) { e.preventDefault(); e.returnValue = ''; }
});
