'use strict';

var Xlsx = (function () {
  var CRC = (function () {
    var t = new Uint32Array(256);
    for (var n = 0; n < 256; n++) {
      var c = n;
      for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();

  function crc32(b) {
    var c = 0xFFFFFFFF;
    for (var i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  function inflate(data) {
    var s = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Response(s).arrayBuffer().then(function (b) { return new Uint8Array(b); });
  }

  function unzip(buf) {
    var u8 = new Uint8Array(buf), dv = new DataView(buf), end = -1;
    for (var i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { end = i; break; }
    }
    if (end < 0) return Promise.reject(new Error('not an xlsx file'));
    var count = dv.getUint16(end + 10, true), p = dv.getUint32(end + 16, true);
    var dec = new TextDecoder(), jobs = [], out = {};
    for (var k = 0; k < count; k++) {
      if (dv.getUint32(p, true) !== 0x02014b50) return Promise.reject(new Error('damaged xlsx file'));
      var method = dv.getUint16(p + 10, true), size = dv.getUint32(p + 20, true);
      var nl = dv.getUint16(p + 28, true), xl = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true);
      var off = dv.getUint32(p + 42, true);
      var name = dec.decode(u8.subarray(p + 46, p + 46 + nl));
      p += 46 + nl + xl + cl;
      var start = off + 30 + dv.getUint16(off + 26, true) + dv.getUint16(off + 28, true);
      var data = u8.subarray(start, start + size);
      if (method === 0) out[name] = data;
      else if (method === 8) jobs.push(inflate(data).then((function (n) {
        return function (d) { out[n] = d; };
      })(name)));
    }
    return Promise.all(jobs).then(function () { return out; });
  }

  function zip(files) {
    var enc = new TextEncoder(), parts = [], dir = [], off = 0;
    files.forEach(function (f) {
      var nm = enc.encode(f.name), data = typeof f.data === 'string' ? enc.encode(f.data) : f.data;
      var crc = crc32(data), sz = data.length;
      var h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true);
      h.setUint16(12, 0x21, true); h.setUint32(14, crc, true); h.setUint32(18, sz, true);
      h.setUint32(22, sz, true); h.setUint16(26, nm.length, true);
      parts.push(new Uint8Array(h.buffer), nm, data);
      var c = new DataView(new ArrayBuffer(46));
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true);
      c.setUint16(8, 0x0800, true); c.setUint16(14, 0x21, true); c.setUint32(16, crc, true);
      c.setUint32(20, sz, true); c.setUint32(24, sz, true); c.setUint16(28, nm.length, true);
      c.setUint32(42, off, true);
      dir.push(new Uint8Array(c.buffer), nm);
      off += 30 + nm.length + sz;
    });
    var dsize = dir.reduce(function (a, b) { return a + b.length; }, 0);
    var e = new DataView(new ArrayBuffer(22));
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true);
    e.setUint16(10, files.length, true); e.setUint32(12, dsize, true); e.setUint32(16, off, true);
    return new Blob(parts.concat(dir, [new Uint8Array(e.buffer)]),
      { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }

  function xml(bytes) {
    return new DOMParser().parseFromString(new TextDecoder().decode(bytes), 'application/xml');
  }
  function tags(node, name) { return Array.prototype.slice.call(node.getElementsByTagNameNS('*', name)); }
  function textOf(node) {
    return tags(node, 't').filter(function (t) {
      return !(t.parentNode && t.parentNode.localName === 'rPh');
    }).map(function (t) { return t.textContent; }).join('');
  }
  function colIndex(ref) {
    var m = /^([A-Z]+)/.exec(ref || ''), n = 0;
    if (!m) return -1;
    for (var i = 0; i < m[1].length; i++) n = n * 26 + m[1].charCodeAt(i) - 64;
    return n - 1;
  }
  function colName(n) {
    var s = '';
    for (n += 1; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + (n - 1) % 26) + s;
    return s;
  }
  function resolve(target) {
    if (target.charAt(0) === '/') return target.slice(1);
    var parts = ('xl/' + target).split('/'), out = [];
    parts.forEach(function (p) { if (p === '..') out.pop(); else if (p !== '.') out.push(p); });
    return out.join('/');
  }

  function read(buf) {
    return unzip(buf).then(function (z) {
      if (!z['xl/workbook.xml']) throw new Error('not an xlsx file');
      var sst = z['xl/sharedStrings.xml'] ? tags(xml(z['xl/sharedStrings.xml']), 'si').map(textOf) : [];
      var rels = {};
      if (z['xl/_rels/workbook.xml.rels']) {
        tags(xml(z['xl/_rels/workbook.xml.rels']), 'Relationship').forEach(function (r) {
          rels[r.getAttribute('Id')] = resolve(r.getAttribute('Target'));
        });
      }
      var sheets = tags(xml(z['xl/workbook.xml']), 'sheet').map(function (s, k) {
        var id = s.getAttribute('r:id') || s.getAttributeNS(
          'http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id');
        var path = rels[id] || 'xl/worksheets/sheet' + (k + 1) + '.xml';
        var rows = [];
        if (z[path]) {
          tags(xml(z[path]), 'row').forEach(function (r) {
            var ri = parseInt(r.getAttribute('r'), 10) - 1;
            if (isNaN(ri)) ri = rows.length;
            var row = rows[ri] = [];
            tags(r, 'c').forEach(function (c, ci) {
              var col = colIndex(c.getAttribute('r'));
              if (col < 0) col = ci;
              var t = c.getAttribute('t'), v = tags(c, 'v')[0], val = null;
              if (t === 'inlineStr') val = textOf(c);
              else if (v) {
                var s = v.textContent;
                if (t === 's') val = sst[parseInt(s, 10)];
                else if (t === 'b') val = s === '1';
                else if (t === 'str' || t === 'e') val = s;
                else val = s === '' ? null : Number(s);
              }
              row[col] = val;
            });
          });
        }
        for (var i = 0; i < rows.length; i++) if (!rows[i]) rows[i] = [];
        return { name: s.getAttribute('name'), rows: rows };
      });
      return { sheets: sheets };
    });
  }

  function esc(s) {
    return String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F￾￿]/g, '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function sheetXml(rows, first) {
    var width = [];
    var body = rows.map(function (row, ri) {
      var cells = '';
      (row || []).forEach(function (v, ci) {
        if (v === null || v === undefined || v === '') return;
        var ref = colName(ci) + (ri + 1), st = ri === 0 ? ' s="1"' : '';
        width[ci] = Math.max(width[ci] || 0, String(v).length);
        if (typeof v === 'number' && isFinite(v)) cells += '<c r="' + ref + '"' + st + '><v>' + v + '</v></c>';
        else if (typeof v === 'boolean') cells += '<c r="' + ref + '"' + st + ' t="b"><v>' + (v ? 1 : 0) + '</v></c>';
        else cells += '<c r="' + ref + '"' + st + ' t="inlineStr"><is><t xml:space="preserve">' +
          esc(v) + '</t></is></c>';
      });
      return '<row r="' + (ri + 1) + '">' + cells + '</row>';
    }).join('');
    var cols = width.length ? '<cols>' + width.map(function (w, ci) {
      return '<col min="' + (ci + 1) + '" max="' + (ci + 1) + '" width="' +
        Math.min(60, Math.max(6, (w || 0) + 2)) + '" customWidth="1"/>';
    }).join('') + '</cols>' : '';
    var view = first ? '<sheetViews><sheetView workbookViewId="0" tabSelected="1"><pane ySplit="1" ' +
      'topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
      : '<sheetViews><sheetView workbookViewId="0"/></sheetViews>';
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
      view + cols + '<sheetData>' + body + '</sheetData></worksheet>';
  }

  function write(book) {
    var n = book.sheets.length, files = [];
    var ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
      '<Default Extension="xml" ContentType="application/xml"/>' +
      '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
      '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
    var wbs = '', wrels = '';
    book.sheets.forEach(function (s, k) {
      ct += '<Override PartName="/xl/worksheets/sheet' + (k + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
      wbs += '<sheet name="' + esc(s.name) + '" sheetId="' + (k + 1) + '" r:id="rId' + (k + 1) + '"/>';
      wrels += '<Relationship Id="rId' + (k + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (k + 1) + '.xml"/>';
      files.push({ name: 'xl/worksheets/sheet' + (k + 1) + '.xml', data: sheetXml(s.rows, k === 0) });
    });
    wrels += '<Relationship Id="rId' + (n + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
    files.unshift(
      { name: '[Content_Types].xml', data: ct + '</Types>' },
      { name: '_rels/.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
        '</Relationships>' },
      { name: 'xl/workbook.xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" ' +
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
        '<bookViews><workbookView/></bookViews><sheets>' + wbs + '</sheets></workbook>' },
      { name: 'xl/_rels/workbook.xml.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
        wrels + '</Relationships>' },
      { name: 'xl/styles.xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
        '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
        '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font>' +
        '<font><b/><sz val="11"/><name val="Calibri"/></font></fonts>' +
        '<fills count="2"><fill><patternFill patternType="none"/></fill>' +
        '<fill><patternFill patternType="gray125"/></fill></fills>' +
        '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>' +
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
        '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' +
        '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>' +
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' +
        '</styleSheet>' }
    );
    return zip(files);
  }

  return { read: read, write: write };
})();
